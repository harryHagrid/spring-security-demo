package com.abhishek.springsecuritydemo.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.abhishek.springsecuritydemo.entity.Customer;
import com.abhishek.springsecuritydemo.entity.CustomerDetail;
import com.abhishek.springsecuritydemo.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements UserDetailsService {
	
	@Autowired
	CustomerRepository customerRepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		try {
			
			Customer customer = this.customerRepo.findByEmail(username).get();
			
			return new CustomerDetail(customer);
		} catch(NoSuchElementException e) {
			
			System.out.println("No User found with email - "+ username);
			throw new UsernameNotFoundException("No User found with email - "+ username);
		}
		
	}

}