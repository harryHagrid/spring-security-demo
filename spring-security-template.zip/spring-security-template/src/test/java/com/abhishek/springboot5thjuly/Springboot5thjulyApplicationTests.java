package com.abhishek.springboot5thjuly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot5thjulyApplicationTests {

	@Test
	void contextLoads() {
	}

}
